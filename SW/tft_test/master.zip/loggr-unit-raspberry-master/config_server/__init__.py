#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
loggr.io - Raspberry Pi Config server Python code
-------------------------------------------------
Code for config server of loggr.io project

Basic usage:
(on Raspberry Pi)

    sudo python run.py --config_server (or automatically in crontab)

Please read documentation for further information.
"""
