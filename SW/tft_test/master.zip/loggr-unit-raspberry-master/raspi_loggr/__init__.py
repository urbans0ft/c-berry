#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
loggr.io - Raspberry Pi Python code
-----------------------------------
Code for metering and sending per HTTP post requests

Basic usage:
(on Raspberry Pi)

    sudo python run.py (or automatically in crontab)

Please read documentation for further information.
"""
